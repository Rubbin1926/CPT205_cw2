#define FREEGLUT_STATIC
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <GL/freeglut.h>

double radiusX = 30;   // x-axis radius of ellipse
double radiusY = 40;  // y-axis radius of the ellipse
double centerX = 60;  // The center X coordinate of the ellipse 1
double centerY = 250;  // The center Y coordinate of the ellipse 1

double centerP = 90;  // The center P coordinate of the ellipse 2
double centerQ = 200;  // The center Q coordinate of the ellipse 2

float r = 0.0;

typedef struct { GLfloat x, y; } point; 
point p0 = { 100,350 }; 
GLfloat finishy = 400; 

GLfloat step = -5; 
int time_interval = 50; 

void when_in_mainloop(){ 
	glutPostRedisplay();
}

void OnTimer(int value)
{
	p0.y += step;
	if (p0.y >= 400)
		p0.y = 0;
	else if (p0.y <= 0)
		p0.y = 399;
	glutTimerFunc(time_interval, OnTimer, 1);
}

void mouse_input(int button, int state, int x, int y) // mouse interactions
{
	if (state == GLUT_DOWN && button == GLUT_LEFT_BUTTON && step >= -15)
		step -= 1; // decrement step
	else if (state == GLUT_DOWN && button == GLUT_RIGHT_BUTTON && step <= 15)
		step += 1; // increment step
}

void keyboard_input(unsigned char key, int a, int b) // keyboard interactions
{
	const float maxRotation = 5.0f; // maximum rotation angle
	const float minRotation = -5.0f;   // minimum rotation angle

	if (key == 'd' || key == 'D') {
		r--;
		if (r < minRotation) {
			r = minRotation; 
		}
	}
	else if (key == 'a' || key == 'A') {
		r++;
		if (r > maxRotation) {
			r = maxRotation; 
		}
	}
}

void display(void)
{
	// set background color
	glClearColor(98 / 255.0f, 41 / 255.0f, 128 / 255.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	// set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, 600, 0, 400);

	// plot auxiliary axis X (red)
	glColor3f(1.0f, 0.0f, 0.0f);
	glBegin(GL_LINES);
	glVertex2f(0, 200); 
	glVertex2f(600, 200); 
	glEnd();

	// plot the auxiliary axis Y (green��
	glColor3f(0.0f, 1.0f, 0.0f); 
	glBegin(GL_LINES);
	glVertex2f(300, 0); 
	glVertex2f(300, 400); 
	glEnd();

	// background rendering
	glBegin(GL_QUADS);
	glColor3f(98 / 255.0f, 41 / 255.0f, 128 / 255.0f);
	glVertex2f(0, 180);
	glColor3f(25 / 255.0f, 25 / 255.0f, 112 / 255.0f);
	glVertex2f(0, 400);
	glColor3f(25 / 255.0f, 25 / 255.0f, 112 / 255.0f);
	glVertex2f(600, 400);
	glColor3f(98 / 255.0f, 41 / 255.0f, 128 / 255.0f);
	glVertex2f(600, 180);
	glEnd();

	// little white pavilion
	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex2f(290, 80);
	glVertex2f(290, 180);
	glVertex2f(310, 180);
	glVertex2f(310, 80);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex2f(200, 80);
	glVertex2f(200, 180);
	glVertex2f(220, 180);
	glVertex2f(220, 80);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex2f(380, 80);
	glVertex2f(380, 180);
	glVertex2f(400, 180);
	glVertex2f(400, 80);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex2f(250, 80);
	glVertex2f(250, 180);
	glVertex2f(260, 180);
	glVertex2f(260, 80);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex2f(340, 80);
	glVertex2f(340, 180);
	glVertex2f(350, 180);
	glVertex2f(350, 80);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_TRIANGLES);
	glVertex2f(200, 180);
	glVertex2f(300, 250);
	glVertex2f(400, 180);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(300, 215);
	for (int i = 0; i <= 180; i++) {
		float angle = i * 3.14159 / 180.0;
		float x = 300 + 50 * cos(angle);
		float y = 215 + 50 * sin(angle);
		glVertex2f(x, y);
	}
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_QUADS);
	glVertex2f(230, 200);
	glVertex2f(230, 215);
	glVertex2f(365, 215);
	glVertex2f(365, 200);
	glEnd();

	// stars
	glColor3f(1, 1, 1);
	glBegin(GL_POLYGON);
	glVertex2f(p0.x - 5, p0.y);
	glVertex2f(p0.x, p0.y + 10);
	glVertex2f(p0.x + 5, p0.y);
	glVertex2f(p0.x, p0.y - 10);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_POLYGON);
	glVertex2f(p0.x + 95, p0.y - 100);
	glVertex2f(p0.x + 100, p0.y - 90);
	glVertex2f(p0.x + 105, p0.y - 100);
	glVertex2f(p0.x + 100, p0.y - 110);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_POLYGON);
	glVertex2f(p0.x + 195, p0.y);
	glVertex2f(p0.x + 200, p0.y + 10);
	glVertex2f(p0.x + 205, p0.y);
	glVertex2f(p0.x + 200, p0.y - 10);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_POLYGON);
	glVertex2f(p0.x + 295, p0.y - 100);
	glVertex2f(p0.x + 300, p0.y - 90);
	glVertex2f(p0.x + 305, p0.y - 100);
	glVertex2f(p0.x + 300, p0.y - 110);
	glEnd();

	glColor3f(1, 1, 1);
	glBegin(GL_POLYGON);
	glVertex2f(p0.x + 395, p0.y);
	glVertex2f(p0.x + 400, p0.y + 10);
	glVertex2f(p0.x + 405, p0.y);
	glVertex2f(p0.x + 400, p0.y - 10);
	glEnd();

	// light (left)
	glBegin(GL_TRIANGLES);
	glColor3f(255 / 255.0f, 250 / 255.0f, 240 / 255.0f);
	glVertex2f(100, 80);
	glColor3f(98 / 255.0f, 41 / 255.0f, 128 / 255.0f);
	glVertex2f(50, 250);
	glColor3f(98 / 255.0f, 41 / 255.0f, 128 / 255.0f);
	glVertex2f(150, 250);
	glEnd();

	// balloons
	glPushMatrix();
	glRotatef(r, 0, 0, 1);
	glColor3f(0.0f, 0.0f, 0.0f);
	glBegin(GL_LINES);
	glVertex2f(centerX, centerY); 
	glVertex2f(75, 80); 
	glEnd();
	glColor3f(219 / 255.0f, 112 / 255.0f, 147 / 255.0f);
	glBegin(GL_POLYGON);
	for (int i = 0; i < 360; i++) {
		double angle = i * 3.14159265 / 180.0;
		double a = centerX + radiusX * cos(angle);
		double b = centerY + radiusY * sin(angle);
		glVertex2f(a, b);
	}
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glRotatef(r, 0, 0, 1);
	glColor3f(0.0f, 0.0f, 0.0f);
	glBegin(GL_LINES);
	glVertex2f(centerP, centerQ);
	glVertex2f(75, 80);
	glEnd();
	glColor3f(65 / 255.0f, 105 / 255.0f, 225 / 255.0f);
	glBegin(GL_POLYGON);
	for (int i = 0; i < 360; i++) {
		double angle = i * 3.14159265 / 180.0;
		double c = centerP + radiusX * cos(angle);
		double d = centerQ + radiusY * sin(angle);
		glVertex2f(c, d);
	}
	glEnd();
	glPopMatrix();

	glColor3f(1, 1, 1);
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(75, 80);
	for (int i = 0; i <= 360; i++) {
		float angle = i * 3.14159 / 180.0;
		float e = 75 + 15 * cos(angle);
		float f = 80 + 15 * sin(angle);
		glVertex2f(e, f);
	}
	glEnd();

	// light (right)
	glBegin(GL_TRIANGLES);
	glColor3f(255 / 255.0f, 250 / 255.0f, 240 / 255.0f);
	glVertex2f(500, 80);
	glColor3f(98 / 255.0f, 41 / 255.0f, 128 / 255.0f);
	glVertex2f(450, 250);
	glColor3f(98 / 255.0f, 41 / 255.0f, 128 / 255.0f);
	glVertex2f(550, 250);
	glEnd();

	// bachelor cap
	glBegin(GL_QUADS);
	glColor3f(34 / 255.0f, 15 / 255.0f, 67 / 255.0f);
	glVertex2f(470, 270);
	glVertex2f(470, 310);
	glColor3f(23 / 255.0f, 10 / 255.0f, 46 / 255.0f);
	glVertex2f(520, 310);
	glVertex2f(520, 270);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0 / 255.0f, 0 / 255.0f, 0 / 255.0f);
	glVertex2f(520, 270);
	glVertex2f(520, 310);
	glVertex2f(535, 330);
	glVertex2f(535, 290);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(21 / 255.0f, 9 / 255.0f, 42 / 255.0f);
	glVertex2f(440, 310);
	glVertex2f(470, 340);
	glVertex2f(550, 340);
	glVertex2f(520, 310);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(495, 325);
	glVertex2f(440, 310);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(440, 310);
	glVertex2f(440, 280);
	glEnd();

	glPointSize(5);
	glColor3f(0.0f, 0.0f, 1.0f);
	glBegin(GL_POINTS);
	glVertex2f(440, 280);
	glEnd();

	// bottom edge
	glBegin(GL_QUADS);
	glColor3f(195 / 255.0f, 195 / 255.0f, 195 / 255.0f);
	glVertex2f(0, 0);
	glColor3f(1, 1, 1);
	glVertex2f(0, 80);
	glColor3f(1, 1, 1);
	glVertex2f(600, 80);
	glColor3f(195 / 255.0f, 195 / 255.0f, 195 / 255.0f);
	glVertex2f(600, 0);
	glEnd();
	glutSwapBuffers();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(600, 400);
	glutCreateWindow("Graduation Ceremony Invitation");
	glutDisplayFunc(display);
	glutIdleFunc(when_in_mainloop);
	glutTimerFunc(time_interval, OnTimer, 1);
	glutMouseFunc(mouse_input); 
	glutKeyboardFunc(keyboard_input);
	glutMainLoop();
}
