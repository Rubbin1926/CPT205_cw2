#define FREEGLUT_STATIC
#include <GL/freeglut.h>
#include <stdlib.h>
#include <stdio.h>
#include<math.h>
#include "vector"
using namespace std;

float fltFOV = 100; //Field Of View
float fltZoom = 1.0; //Zoom amount
float fltX0 = 0.0; //Camera position
float fltY0 = 50.0;
float fltZ0 = -500.0;
float fltXRef = 0.0; //Look At reference point
float fltYRef = 0.0;
float fltZRef = 0.0;
float fltXUp = 0.0; //Up vector
float fltYUp = 1.0;
float fltZUp = 0.0;
float fltViewingAngle = 0;

GLint imagewidth0, imagewidth1;
GLint imageheight0, imageheight1;
GLint pixellength0, pixellength1;
vector<GLubyte*>p; 
GLuint texture[2];
GLfloat angle = 0;
void ReadImage(const char path[256], GLint& imagewidth, GLint& imageheight, GLint& pixellength) {
	GLubyte* pixeldata;
	FILE* pfile;
	fopen_s(&pfile, path, "rb");
	if (pfile == 0) exit(0);
	fseek(pfile, 0x0012, SEEK_SET);
	fread(&imagewidth, sizeof(imagewidth), 1, pfile);
	fread(&imageheight, sizeof(imageheight), 1, pfile);
	pixellength = imagewidth * 3;
	while (pixellength % 4 != 0)pixellength++;
	pixellength *= imageheight;
	pixeldata = (GLubyte*)malloc(pixellength);
	if (pixeldata == 0) exit(0);
	fseek(pfile, 54, SEEK_SET);
	fread(pixeldata, pixellength, 1, pfile);
	p.push_back(pixeldata); 
	fclose(pfile);
}



void GL_LOADTEXTURE(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glShadeModel(GL_FLAT);
	glEnable(GL_TEXTURE_2D);
	ReadImage("Image.bmp", imagewidth0, imageheight0, pixellength0);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1); // set pixel storage modes (in the memory)
	glGenTextures(1, &texture[0]); // number of texture names to be generated and an array of texture names
	glBindTexture(GL_TEXTURE_2D, texture[0]); // target to which texture is bound and name of a texture
	glTexImage2D(GL_TEXTURE_2D, 0, 3, imagewidth0, imageheight0, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, p[0]);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
}


void myinit() {
	glEnable(GL_LIGHTING); 

	GLfloat light_position[] = { 100.0, 100.0, -100.0, 1.0 }; 
	GLfloat white_light[] = { 121.0 / 255.0f, 111.0 / 255.0f, 79.0 / 255.0f, 1.0 };
	GLfloat ambient_light[] = { 1.0, 1.0, 1.0, 1.0 };

	glLightfv(GL_LIGHT0, GL_POSITION, light_position); 
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light); 
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light); 
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient_light); 

	glEnable(GL_LIGHT0); 
	glEnable(GL_DEPTH_TEST); 
}

void teapot()
{
	GLfloat mat_diffuse_teapot[] = { 100 / 255.0f, 224 / 255.0f, 230 / 255.0f, 1.0 };
	GLfloat mat_specular_teapot[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_shininess_teapot[] = { 50.0 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse_teapot);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular_teapot);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess_teapot);
	glPushMatrix();
	glTranslatef(200.0, 20.0, 0.0);
	glColor3f(176 / 255.0f, 224 / 255.0f, 230 / 255.0f);
	glutSolidTeapot(25);
	glFlush();
	glPopMatrix();
}

void bear()
{
	GLfloat mat_diffuse_bear[] = { 255 / 255.0f, 182 / 255.0f, 193 / 255.0f, 1.0 };
	GLfloat mat_specular_bear[] = { 1.0, 0.0, 1.0, 1.0 };
	GLfloat mat_shininess_bear[] = { 5.0 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse_bear);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular_bear);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess_bear);
	
	glPushMatrix();
	glTranslatef(-150.0, -150.0, -150.0);
	glScalef(50.0, 50.0, 50.0);
	glColor3f(244 / 255.0f, 164 / 255.0f, 96 / 255.0f);
	glutSolidSphere(1.0, 50, 50);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-150.0, -100.0, -150.0);
	glScalef(40.0, 40.0, 40.0);
	glColor3f(244 / 255.0f, 164 / 255.0f, 96 / 255.0f);
	glutSolidSphere(1.0, 50, 50);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-150.0, -100.0, -152.0);
	glScalef(39.0, 39.0, 39.0);
	glColor3f(210 / 255.0f, 105 / 255.0f, 30 / 255.0f);
	glutSolidSphere(1.0, 50, 50);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-125.0, -55.0, -150.0);
	glScalef(15.0, 15.0, 15.0);
	glColor3f(244 / 255.0f, 164 / 255.0f, 96 / 255.0f);
	glutSolidSphere(1.0, 50, 50);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-175.0, -55.0, -150.0);
	glScalef(15.0, 15.0, 15.0);
	glColor3f(244 / 255.0f, 164 / 255.0f, 96 / 255.0f);
	glutSolidSphere(1.0, 50, 50);
	glPopMatrix();
}

void desk()
{
	glPushMatrix();
	glTranslatef(200.0, -10.0, 0.0);
	glScalef(100.0, 10.0, 100.0);
	GLfloat mat_diffuse_desk[] = { 0.5f, 0.5f, 0.5f, 1.0f }; 
	GLfloat mat_specular_desk[] = { 0.0f, 0.0f, 0.0f, 1.0f }; 
	GLfloat mat_shininess_desk[] = { 0.0f };

	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse_desk);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular_desk);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess_desk);

	glColor3f(188 / 255.0f, 143 / 255.0f, 143 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(290.0, -110.0, 90.0);
	glScalef(10.0, 100.0, 10.0);
	glColor3f(210 / 255.0f, 180 / 255.0f, 140 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(290.0, -110.0, -90.0);
	glScalef(10.0, 100.0, 10.0);
	glColor3f(210 / 255.0f, 180 / 255.0f, 140 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(110.0, -110.0, 90.0);
	glScalef(10.0, 100.0, 10.0);
	glColor3f(210 / 255.0f, 180 / 255.0f, 140 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(110.0, -110.0, -90.0);
	glScalef(10.0, 100.0, 10.0);
	glColor3f(210 / 255.0f, 180 / 255.0f, 140 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();
	glPopMatrix();

	glDisable(GL_LIGHTING); // disable lighting
	glDisable(GL_LIGHT0); // turn off light source
}


void display()
{
	glEnable(GL_NORMALIZE); // enable normal normalization
	glPushMatrix();
	teapot();
	bear();
	desk();
	glPopMatrix();

	//carpet
	glPushMatrix();
	glTranslatef(0.0, -199.0, 0.0);
	glScalef(200.0, 20.0, 200.0);
	glColor3f(100 / 255.0f, 149 / 255.0f, 237 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	//wall
	glPushMatrix();
	glTranslatef(0.0, -200.0, 0.0);
	glScalef(400.0, 20.0, 400.0);
	glColor3f(150 / 255.0f, 205 / 255.0f, 205 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	GL_LOADTEXTURE();
	glPushMatrix();
	glTranslatef(0.0, 220.0, 380);
	glScalef(400.0, 400.0, 20);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture[0]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3f(-1.0, -1.0, 1.0);
	glTexCoord2f(1.0, 0.0); glVertex3f(1.0, -1.0, 1.0);
	glTexCoord2f(1.0, 1.0); glVertex3f(1.0, 1.0, 1.0);
	glTexCoord2f(0.0, 1.0); glVertex3f(-1.0, 1.0, 1.0);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glBindTexture(GL_TEXTURE_2D, 0);

	glPushMatrix();
	glTranslatef(380.0, 220.0, 0.0);
	glScalef(20.0, 400.0, 400.0);
	glColor3f(216 / 255.0f, 191 / 255.0f, 216 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(-380.0, 220.0, 0.0);
	glScalef(20.0, 400.0, 400.0);
	glColor3f(216 / 255.0f, 191 / 255.0f, 216 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.0, 600.0, 0.0);
	glScalef(400.0, 20.0, 400.0);
	glColor3f(143 / 255.0f, 188 / 255.0f, 143 / 255.0f);
	glutSolidCube(2);
	glPopMatrix();

	glPopMatrix();
	glFlush();
}

void displayObject()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fltFOV, 1, 0.1, 5000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(fltX0 * fltZoom, fltY0 * fltZoom, fltZ0 * fltZoom, fltXRef, fltYRef, fltZRef, fltXUp,
		fltYUp, fltZUp);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING); 
	glEnable(GL_LIGHT0); 
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	display();
	glutSwapBuffers();
}

void myReshape(GLsizei w, GLsizei h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, 1.0 * (GLfloat)w / (GLfloat)h, 0.0, 300.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}


void adjustDisplay(unsigned char key, int x, int y)
{
	if (key == 'd' || key == 'D') {
		if (fltY0 > -500)
			fltY0 -= 5; // Camera down
	}
	else if (key == 'u' || key == 'U') {
		if (fltY0 < 500)
			fltY0 += 5; // Camera up
	}
	else if (key == 'i' || key == 'I') {
		if (fltZoom > 0.2)
			fltZoom -= 0.01; // Zoom in
	}
	else if (key == 'o' || key == 'O') {
		if (fltZoom < 5.0)
			fltZoom += 0.01; // Zoom out
	}
	else if (key == 'r' || key == 'R') {
		// Rotate camera left around the scene
		fltViewingAngle -= 5.0;
		fltX0 = sin(fltViewingAngle * 3.14159 / 180.0) * 500.0;
		fltZ0 = -cos(fltViewingAngle * 3.14159 / 180.0) * 500.0;
	}
	else if (key == 'l' || key == 'L') {
		// Rotate camera right around the scene
		fltViewingAngle += 5.0;
		fltX0 = sin(fltViewingAngle * 3.14159 / 180.0) * 500.0;
		fltZ0 = -cos(fltViewingAngle * 3.14159 / 180.0) * 500.0;
	}
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowPosition(500, 100);
	glutInitWindowSize(800, 600);
	if (!glutCreateWindow("Toy House"))
		exit(0);
	glutReshapeFunc(myReshape);
	glutDisplayFunc(displayObject);
	glutKeyboardFunc(adjustDisplay);
	myinit();
	glutMainLoop();
}

